# Install the profile

Copy README.md and the assets folder into the root of Farazhaghgoo/Farazhaghgoo. Keep assets/header.svg at that path. SETUP.md is for you and does not need to be uploaded.

The draft is prepared locally; it has not been published to GitHub.

## Contribution visibility

The signed-out public profile displayed 83 contributions in the last year on September 24, 2026. The 600+ total reported by you was not independently visible. Private contribution visibility is the likely cause of that difference, but it is not confirmed.

While signed in, open your GitHub profile, scroll to the contribution graph, open Contribution settings, and enable Private contributions. GitHub can display anonymized counts without exposing private repository names or contents. Compare the same date range in your signed-in and signed-out views. If a gap remains, check organization SSO restrictions and GitHub contribution eligibility rules.

The redesigned README removes the external stats cards. It does not replace the total with an unverified or hardcoded number. GitHub's native contribution graph remains below the profile.

Reference: https://docs.github.com/en/account-and-profile/reference/profile-contributions-reference

## Suggested sidebar bio

Developer & builder in Turin. Web, mobile, and interactive interfaces. Exploring AI-assisted product development.

## Suggested pins

Whomst, Ledger (financeApp), VeloCity, and AI Career Partner (CVai).

## Editorial checks

- Public project descriptions checked against their repository READMEs.
- Inrebus stack checked against the local project package manifest; Vercel included from your description.
- HMI DAO stack checked against local package manifests and Three.js usage. Only the project name, general status, and technologies are disclosed.
- LinkedIn public profile confirmed Turin and inRebus affiliation. Its recent public post informed the AI-assisted building paragraph; gated experience details were not accessed.
- AI Career Partner is described as a UI prototype using mock data.
- VeloCity is described as a landing-page experience, without claiming a production data-room service.
